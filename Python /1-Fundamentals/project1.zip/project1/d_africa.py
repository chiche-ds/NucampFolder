from quiz_pkg import QandA , welcome

welcome.message()

print("Enter your name to proceed ") 
name = input("Enter your name:   ")

print("======= ", name ,"=======" )
print("   Wellcome to Afriq IQ   ")


QandA.logic()


""" 
Redo this quiz add authentication, multiple choice questions, differnt levels , user profiles , segment question into different topics and level. its should be like a course where you 
start with basic quesetions and as it progresses you move to different levels 


 """