def message():
    print("")
    print("          === Welcome Afri-IQ  ===          ")
    print(" A place where you learn more about the African continent")
    
   





